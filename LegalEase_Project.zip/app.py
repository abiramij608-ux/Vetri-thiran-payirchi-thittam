import io
import re
import requests
import streamlit as st
from docx import Document
from docx.shared import Pt
from fpdf import FPDF

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")

API_URL = st.sidebar.text_input("Backend URL", "http://127.0.0.1:8000")

st.subheader("Create Your Legal Document")

document_type = st.selectbox(
    "Document Type",
    ["Agreement", "Contract", "NDA", "Lease Agreement", "Employment Offer Letter",
     "Freelance Work Contract", "Other"]
)

parties = st.text_area(
    "Parties Involved",
    placeholder="Example: Jane Doe (Service Provider), TechNova Inc. (Client)"
)

terms = st.text_area(
    "Terms & Conditions",
    placeholder="Separate each term with a semicolon (;)"
)

dates = st.text_input(
    "Effective Date",
    placeholder="Example: April 15, 2025"
)

if "document" not in st.session_state:
    st.session_state.document = ""

if st.button("Generate Document", type="primary"):
    if not parties or not terms or not dates:
        st.warning("Please fill in all required fields.")
    else:
        try:
            response = requests.post(
                f"{API_URL}/generate",
                json={
                    "document_type": document_type,
                    "parties": parties,
                    "terms": terms,
                    "dates": dates
                },
                timeout=120
            )
            response.raise_for_status()
            st.session_state.document = response.json()["document"]
            st.success("Document generated successfully.")
        except Exception as e:
            st.error(f"Could not connect to the backend: {e}")

if st.session_state.document:
    st.subheader("Document Preview / Edit")
    st.session_state.document = st.text_area(
        "Click here to edit the generated document",
        value=st.session_state.document,
        height=500
    )

    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            "Download TXT",
            st.session_state.document,
            file_name="LegalEase_Document.txt",
            mime="text/plain"
        )

    with col2:
        doc = Document()
        title = doc.add_paragraph()
        run = title.add_run(document_type)
        run.bold = True
        run.font.size = Pt(16)
        for paragraph in st.session_state.document.split("\n"):
            doc.add_paragraph(paragraph)
        buffer = io.BytesIO()
        doc.save(buffer)
        st.download_button(
            "Download DOCX",
            buffer.getvalue(),
            file_name="LegalEase_Document.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

    with col3:
        def make_pdf(text):
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()
            pdf.set_font("Times", "B", 16)
            pdf.cell(0, 10, document_type, ln=True, align="C")
            pdf.ln(5)
            pdf.set_font("Times", size=11)
            for line in text.split("\n"):
                clean = re.sub(r"[^\x00-\x7F]+", "", line)
                pdf.multi_cell(0, 7, clean)
            return bytes(pdf.output())

        st.download_button(
            "Download PDF",
            make_pdf(st.session_state.document),
            file_name="LegalEase_Document.pdf",
            mime="application/pdf"
        )

st.divider()
st.caption("LegalEase generates drafts for informational purposes. Review important documents with a qualified legal professional.")
