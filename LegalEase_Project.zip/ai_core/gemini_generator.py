import os
from dotenv import load_dotenv

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")

    def generate_document(self, document_type, parties, terms, dates):
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is missing in the .env file.")

        # Current Google Gemini SDK compatibility.
        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)

            prompt = f"""
You are a legal document drafting assistant.
Create a clear, structured draft of a {document_type}.

Parties:
{parties}

Terms and conditions:
{terms}

Effective date:
{dates}

Requirements:
- Use clear headings and numbered clauses.
- Include the supplied information accurately.
- Do not invent important personal or financial details.
- Clearly label the result as a draft.
- Do not claim that the document is a substitute for advice from a qualified lawyer.
"""
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )
            return response.text

        except ImportError:
            raise RuntimeError(
                "Install the current Google GenAI SDK with: pip install google-genai"
            )
