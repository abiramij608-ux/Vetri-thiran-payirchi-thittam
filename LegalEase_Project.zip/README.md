# LegalEase – AI-Powered Legal Document Generator

LegalEase uses a Streamlit frontend, FastAPI backend, and Google Gemini to generate editable legal-document drafts.

## 1. Install

```bash
pip install -r requirements.txt
```

## 2. Configure Gemini

Copy `.env.example` to `.env` and add your Gemini API key:

```text
GEMINI_API_KEY=your_key_here
```

Keep `.env` private. Do not upload it to GitHub.

## 3. Start the FastAPI backend

```bash
uvicorn main:app --reload
```

Backend:
http://127.0.0.1:8000

## 4. Start the Streamlit frontend

Open another terminal:

```bash
streamlit run app.py
```

## 5. Use the application

Enter:
- Document type
- Parties involved
- Terms and conditions
- Effective date

Click **Generate Document**, edit the result, then download TXT, DOCX, or PDF.

## Project structure

```text
LegalEase/
├── main.py
├── routes.py
├── app.py
├── requirements.txt
├── .env.example
├── README.md
└── ai_core/
    ├── __init__.py
    └── gemini_generator.py
```

This project creates legal-document drafts; generated content should be reviewed before real-world legal use.
